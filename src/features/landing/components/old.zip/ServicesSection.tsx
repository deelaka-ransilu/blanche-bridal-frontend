"use client";

import Link from "next/link";
import { ThreeDCardEffect } from "@/components/ui/3d-card-effect";
import { motion } from "framer-motion";

const services = [
  {
    icon: "◈",
    title: "Rent a Gown",
    description:
      "Choose from our curated collection of designer bridal gowns. Affordable luxury with full fitting support included.",
    highlight: "From LKR 15,000",
    cta: "Browse Rentals",
    // Filters by rental type in your catalog — adjust the query param to match your ProductType enum
    href: "/catalog?type=RENTAL",
    ctaStyle: "primary",
  },
  {
    icon: "✦",
    title: "Purchase a Gown",
    description:
      "Own your dream gown forever. A wide selection across styles and budgets — from elegant ballgowns to sleek modern silhouettes.",
    highlight: "Personalised pricing",
    cta: "Shop Gowns",
    href: "/catalog?type=SALE",
    ctaStyle: "primary",
  },
  {
    icon: "❋",
    title: "Accessories",
    description:
      "Complete your bridal look with our handpicked accessories — veils, tiaras, jewellery, and more.",
    highlight: "Shop the full range",
    cta: "Shop Accessories",
    href: "/catalog?type=ACCESSORY",
    ctaStyle: "primary",
  },
  {
    icon: "◇",
    title: "Styling Consultation",
    description:
      "Our experienced stylists help you find the perfect gown that complements your body, personality and wedding theme.",
    highlight: "Complimentary session",
    cta: "Book a Fitting",
    href: "/booking",
    ctaStyle: "outline",
  },
];

export default function ServicesSection() {
  return (
    <section id="services" className="bg-[#E9D9B6] py-24 px-6 lg:px-12">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <p className="text-xs tracking-[0.2em] text-[#A86A4B] uppercase mb-3">
            What we offer
          </p>
          <h2 className="text-3xl lg:text-4xl font-light text-[#5B3E26]">
            Our <em className="italic text-[#A86A4B]">services</em>
          </h2>
          <p className="mt-4 text-sm text-[#5B3E26]/70 max-w-md mx-auto leading-relaxed">
            Everything you need for your perfect bridal look — in one place.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, i) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.12 }}
              className="h-full"
            >
              <ThreeDCardEffect>
                <div className="bg-[#F8F4E3] border border-[#D9C4A0] rounded-2xl p-7 h-full flex flex-col gap-5">
                  {/* Icon */}
                  <div className="w-11 h-11 rounded-full bg-[#E9D9B6] flex items-center justify-center text-[#A86A4B] text-lg shrink-0">
                    {service.icon}
                  </div>

                  {/* Text */}
                  <div className="flex-1">
                    <h3 className="text-base font-medium text-[#5B3E26] mb-2">
                      {service.title}
                    </h3>
                    <p className="text-sm text-[#5B3E26]/75 leading-relaxed">
                      {service.description}
                    </p>
                  </div>

                  {/* Price / tag */}
                  <span className="text-xs bg-[#E9D9B6] text-[#A86A4B] px-3 py-1 rounded-full tracking-wide border border-[#D9C4A0] w-fit">
                    {service.highlight}
                  </span>

                  {/* CTA — this is the part that was missing */}
                  <Link
                    href={service.href}
                    className={`mt-auto inline-flex items-center justify-center gap-1.5 text-xs font-medium tracking-wide px-4 py-2.5 rounded-full transition-all duration-200 ${
                      service.ctaStyle === "primary"
                        ? "bg-[#A86A4B] text-white hover:bg-[#8f5a3c]"
                        : "border border-[#A86A4B] text-[#A86A4B] hover:bg-[#A86A4B] hover:text-white"
                    }`}
                  >
                    {service.cta}
                    <svg viewBox="0 0 16 16" fill="none" className="w-3 h-3">
                      <path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </Link>
                </div>
              </ThreeDCardEffect>
            </motion.div>
          ))}
        </div>

        {/* Secondary CTA bar — inquiry path for users who want to ask first */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-12 text-center"
        >
          <p className="text-sm text-[#5B3E26]/60 mb-3">
            Not sure where to start?
          </p>
          <Link
            href="/inquiry"
            className="inline-flex items-center gap-2 text-xs font-medium tracking-[0.12em] uppercase text-[#A86A4B] border-b border-[#A86A4B]/40 hover:border-[#A86A4B] transition-colors duration-200 pb-0.5"
          >
            Send us an inquiry
            <svg viewBox="0 0 16 16" fill="none" className="w-3 h-3">
              <path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </Link>
        </motion.div>
      </div>
    </section>
  );
}